export default function Footer() {
	return (
		<div className='text-center p-10 border-t'>Belajar Next.js dengan <span className='font-bold'>Baris Kode</span></div>
	)
}
