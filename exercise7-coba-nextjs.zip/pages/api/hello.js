export default function handler(req, req) {
	res.status(200).json({name: 'John Doe'})
}
